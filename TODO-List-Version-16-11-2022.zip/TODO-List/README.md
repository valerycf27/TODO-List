# Django-To-Do-list-with-user-authentication
To Do list app with User Registration, Login, Search and full Create Read Update and DELETE functionality.

![DEMO](../master/Django%20To%20Do%20List%20App.jpg)
